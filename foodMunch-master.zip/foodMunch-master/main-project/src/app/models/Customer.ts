// export class Customer{
//     constructor(public customer_id:any,public email:string,public password:string,public name:string,public address:string,public phone_no:any){}
    
// }