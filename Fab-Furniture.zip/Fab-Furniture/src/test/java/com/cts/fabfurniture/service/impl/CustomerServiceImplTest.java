package com.cts.fabfurniture.service.impl;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cts.fabfurniture.entity.Customer;
import com.cts.fabfurniture.exception.CustomException;
import com.cts.fabfurniture.repository.CustomerRepository;



@ExtendWith(MockitoExtension.class)
class CustomerServiceImplTest {
	
	@Mock
	private CustomerRepository customerRepository;
	
	@InjectMocks 
	private CustomerServiceImpl customerServiceImpl;
	
	
	
	Customer customer=new Customer(1,"kashif","kashif@gmail.com","89888899","jfjdfjdj","abc@123");

	@Test
	void testCreateCustomer() {
	when(customerRepository.save(customer)).thenReturn(customer);
	customerServiceImpl.createCustomer(customer);
	verify(customerRepository,times(1)).save(customer);
	}

	@Test
	void testUpdateCustomer() {
		when(customerRepository.save(customer)).thenReturn(customer);
		customerServiceImpl.updateCustomer(customer);
		verify(customerRepository,times(1)).save(customer);
	}

	@Test
	void testDeleteCustomer() throws CustomException {
		when(customerRepository.findById(1)).thenReturn(Optional.of(customer));
		doNothing().when(customerRepository).delete(customer);
		
		customerServiceImpl.deleteCustomer(1);
		
		verify(customerRepository,times(1)).delete(customer);
		
	}
	
	@Test
	void testDeleteCustomerWhenNoCustomerFound() throws CustomException{
		when(customerRepository.findById(1)).thenReturn(Optional.empty());
		Exception exception =assertThrows(CustomException.class, ()->{
			customerServiceImpl.deleteCustomer(1);
		});
		assertEquals("Customer with customer Id 1 does not exist", exception.getMessage());
		verify(customerRepository,never()).delete(customer);
	}

	@Test
	void testReadCustomer() throws CustomException {
		when(customerRepository.findById(1)).thenReturn(Optional.of(customer));
		customerServiceImpl.readCustomer(1);
		verify(customerRepository,times(1)).findById(1);
		
	}
	
	@Test
	void testReadCustomerWhenNoCustomerExist() throws CustomException{
		when(customerRepository.findById(1)).thenReturn(Optional.empty());
		Exception exception=assertThrows(CustomException.class, ()->{
			customerServiceImpl.readCustomer(1);
		});
		assertEquals("Customer with customer Id 1 does not exist", exception.getMessage());
		verify(customerRepository,times(1)).findById(1);
	}

	@Test
	void testReadAllCustomer() {
		when(customerRepository.findAll()).thenReturn(Arrays.asList(customer));
		
		List<Customer> list = customerServiceImpl.readAllCustomer();
		
		assertNotNull(list);
		
		assertEquals(1, list.size());
	}

	@Test
	void testFindByEmailId() throws CustomException {
		when(customerRepository.findByEmailId("kashif@gmail.com")).thenReturn(Optional.of(customer));
		customerServiceImpl.findByEmailId("kashif@gmail.com");
		verify(customerRepository,times(1)).findByEmailId("kashif@gmail.com");
	}
	
	@Test
	void testFindByEmailIdWhenNoEmailIdFound() throws CustomException{
		when(customerRepository.findByEmailId("kashif@gmail.com")).thenReturn(Optional.empty());
		Exception exception=assertThrows(CustomException.class, ()->{
			customerServiceImpl.findByEmailId("kashif@gmail.com");
		});
		assertEquals("Customer with email Id kashif@gmail.com is not present", exception.getMessage());
		verify(customerRepository,times(1)).findByEmailId("kashif@gmail.com");
		
	}

	@Test
	void testLoginCustomer() throws CustomException {
		when(customerRepository.findByEmailId("kashif@gmail.com")).thenReturn(Optional.of(customer));
		Customer c= customerServiceImpl.loginCustomer("kashif@gmail.com", "abc@123");
		assertEquals("abc@123", c.getPassword());
		verify(customerRepository,times(1)).findByEmailId("kashif@gmail.com");
		
	}
	
	@Test
	void testLoginCustomerWhenNoCustomerFound() throws CustomException {
		when(customerRepository.findByEmailId("kashif@gmail.com")).thenReturn(Optional.empty());
		
		Exception exception=assertThrows(CustomException.class, ()->{
		 customerServiceImpl.loginCustomer("kashif@gmail.com", "abc@123");
		});
		assertEquals("No Customer found with email Id kashif@gmail.com", exception.getMessage());
		
		verify(customerRepository,times(1)).findByEmailId("kashif@gmail.com");
		
	}
	
	@Test
	void testLoginCustomerWhenPasswordDoesNotMatch() throws CustomException {
		
		when(customerRepository.findByEmailId("kashif@gmail.com")).thenReturn(Optional.of(customer));
		
		Exception exception=assertThrows(CustomException.class, ()->{
			 customerServiceImpl.loginCustomer("kashif@gmail.com", "bc@123");
		});
		
		assertEquals("Password does not match", exception.getMessage());
		
		verify(customerRepository,times(1)).findByEmailId("kashif@gmail.com");
		
	}
	
	

}
