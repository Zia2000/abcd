package com.cts.fabfurniture.controller;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Date;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.cts.fabfurniture.entity.Customer;
import com.cts.fabfurniture.entity.Furniture;
import com.cts.fabfurniture.entity.Orders;
import com.cts.fabfurniture.entity.Product;
import com.cts.fabfurniture.service.OrdersService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

@SpringBootTest
@AutoConfigureMockMvc
class OrdersControllerTest {
	
	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private OrdersService ordersService;
	
	private static ObjectMapper objectMapper;
	private Product p=new Product();
	
	private Customer customer=new Customer(1,"kashif","kashif@gmail.com","89888899","jfjdfjdj","abc@123");
	
	private Furniture furniture = new Furniture(1, "sofa", "english willow", "yes", customer);
	
	private Orders order=new Orders(1,50000,new Date(),new Date(),customer,furniture);
	
	@BeforeAll
	public static void setup() {
		objectMapper=new ObjectMapper();
		objectMapper.registerModules(new JavaTimeModule());
		objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
	}

	@Test
	void testGetOrders() throws Exception {
		when(ordersService.readAllOrders()).thenReturn(Arrays.asList(order));
		mockMvc.perform(MockMvcRequestBuilders.get("/orders").accept(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk()).andExpect(MockMvcResultMatchers.jsonPath("$.length()").value(1));
	}
	
	@Test
	void testGetOrdersByTotalAmount() throws Exception {
		when(ordersService.findOrdersByTotalAmount(50000)).thenReturn(Arrays.asList(order));
		mockMvc.perform(MockMvcRequestBuilders.get("/orders?totalAmount=50000").accept(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk()).andExpect(MockMvcResultMatchers.jsonPath("$.length()").value(1));
	}
	
	@Test
	void testGetOrdersByCustomerId() throws Exception {
		when(ordersService.findOrdersByCustomerId(1)).thenReturn(Arrays.asList(order));
		mockMvc.perform(MockMvcRequestBuilders.get("/orders?customerId=1").accept(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk()).andExpect(MockMvcResultMatchers.jsonPath("$.length()").value(1));
	}

	@Test
	void testGetOrdersByFurnitureId() throws Exception {
		when(ordersService.findOrdersByFurnitureId(1)).thenReturn(Arrays.asList(order));
		mockMvc.perform(MockMvcRequestBuilders.get("/orders?furnitureId=1").accept(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk()).andExpect(MockMvcResultMatchers.jsonPath("$.length()").value(1));
	}
	
	@Test
	void testGetOrder() throws Exception {
		when(ordersService.readOrder(1)).thenReturn(order);
		mockMvc.perform(MockMvcRequestBuilders.get("/orders/1").accept(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk()).andExpect(MockMvcResultMatchers.jsonPath("$.orderId").value(1));
	}

	@Test
	void testSaveOrder() throws  Exception {
		when(ordersService.createOrder(order)).thenReturn(order);
		mockMvc.perform(MockMvcRequestBuilders.post("/orders").contentType(MediaType.APPLICATION_JSON).content(objectMapper.writeValueAsBytes(order)).accept(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isCreated()).andExpect(MockMvcResultMatchers.jsonPath("$.orderId").value(1));
	}

	@Test
	void testUpdateOrder() throws Exception {
		when(ordersService.updateOrder(order)).thenReturn(order);
		mockMvc.perform(MockMvcRequestBuilders.put("/orders").contentType(MediaType.APPLICATION_JSON).content(objectMapper.writeValueAsBytes(order)).accept(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk()).andExpect(MockMvcResultMatchers.jsonPath("$.orderId").value(1));
	}

	@Test
	void testDeleteOrder() throws Exception {
		doNothing().when(ordersService).deleteOrder(1);
		mockMvc.perform(MockMvcRequestBuilders.delete("/orders/1"));
	}

}
