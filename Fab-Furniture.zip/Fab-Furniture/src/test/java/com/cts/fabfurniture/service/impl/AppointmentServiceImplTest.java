package com.cts.fabfurniture.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cts.fabfurniture.entity.Appointment;
import com.cts.fabfurniture.entity.Customer;
import com.cts.fabfurniture.exception.CustomException;
import com.cts.fabfurniture.repository.AppointmentRepository;
import com.cts.fabfurniture.repository.CustomerRepository;

@ExtendWith(MockitoExtension.class)

class AppointmentServiceImplTest  {
	
	@Mock
	private AppointmentRepository appointmentRepository;
	
	@Mock
	private CustomerRepository customerRepository;
    
    @InjectMocks
    private AppointmentServiceImpl appointmentServiceImpl;
    
    Customer customer=new Customer(1,"kashif","kashif@gmail.com","89888899","jfjdfjdj","abc@123");
    
    private Appointment appointment=new Appointment(1,"in store","Chennai",new Date(),customer);
    
    

	@Test
	void testCreateAppointment() {
		when(appointmentRepository.save(appointment)).thenReturn(appointment);
		appointmentServiceImpl.createAppointment(appointment);
		verify(appointmentRepository,times(1)).save(appointment);
	}

	@Test
	void testReadAppointment() throws CustomException {
		when(appointmentRepository.findById(1)).thenReturn(Optional.of(appointment));
		appointmentServiceImpl.readAppointment(1);
		verify(appointmentRepository,times(1)).findById(1);
	}
	
	@Test
	void testReadAppointmentWhenNoAppointmentFound() throws CustomException {
		when(appointmentRepository.findById(1)).thenReturn(Optional.empty());
		Exception exception=assertThrows(CustomException.class, ()->{
			appointmentServiceImpl.readAppointment(1);
		});
		assertEquals("No appointments with appointment Id 1", exception.getMessage());
		verify(appointmentRepository,times(1)).findById(1);
	}

	@Test
	void testReadAllAppointments() {
		when(appointmentRepository.findAll()).thenReturn(Arrays.asList(appointment));
		List<Appointment> list=appointmentServiceImpl.readAllAppointments();
		assertNotNull(list);
		verify(appointmentRepository,times(1)).findAll();
	}

	@Test
	void testUpdateAppointment() {
		when(appointmentRepository.save(appointment)).thenReturn(appointment);
		appointmentServiceImpl.updateAppointment(appointment);
		verify(appointmentRepository,times(1)).save(appointment);
	}

	@Test
	void testDeleteAppointment() throws CustomException {
		when(appointmentRepository.findById(1)).thenReturn(Optional.of(appointment));
		doNothing().when(appointmentRepository).delete(appointment);
		appointmentServiceImpl.deleteAppointment(1);
		verify(appointmentRepository,times(1)).findById(1);
		verify(appointmentRepository,times(1)).delete(appointment);
	}
	
	@Test
	void testDeleteAppointmentWhenNoAppointmentFound() {
		when(appointmentRepository.findById(1)).thenReturn(Optional.empty());
		Exception exception=assertThrows(CustomException.class, ()->{
		   appointmentServiceImpl.deleteAppointment(1);
		});
		assertEquals("No appointment present with appointment Id 1", exception.getMessage());
		verify(appointmentRepository,times(1)).findById(1);
		verify(appointmentRepository,never()).delete(appointment);
	}

	@Test
	void testFindAppointmentsByLocation() throws CustomException {
		when(appointmentRepository.findByLocation("Chennai")).thenReturn(Arrays.asList(appointment));
		List<Appointment> list=appointmentServiceImpl.findAppointmentsByLocation("Chennai");
		assertNotNull(list);
		verify(appointmentRepository,times(1)).findByLocation("Chennai");
		
		
	}
	
	@Test
	void testFindAppointmentByLocationWhenLocationIsWrong() throws CustomException {
		when(appointmentRepository.findByLocation("Bangalore")).thenReturn(new ArrayList<>());
		Exception exception=assertThrows(CustomException.class, ()->{
			appointmentServiceImpl.findAppointmentsByLocation("Bangalore");
		});
		assertEquals("No appointments for the Bangalore loaction", exception.getMessage());
		verify(appointmentRepository,times(1)).findByLocation("Bangalore");
		
	}	

	@Test
	void testFindAppointmentsByAppointmentType() throws CustomException {
		when(appointmentRepository.findByAppointmentType("in store")).thenReturn(Arrays.asList(appointment));
		List<Appointment> list= appointmentServiceImpl.findAppointmentsByAppointmentType("in store");
		assertNotNull(list);
		verify(appointmentRepository,times(1)).findByAppointmentType("in store");
		
	}
	
	@Test
	void testFindAppointmentsByAppointmentTypeWhenNoAppointmentFound() {
		when(appointmentRepository.findByAppointmentType("delievery consultation")).thenReturn(new ArrayList<>());
		Exception exception=assertThrows(CustomException.class, ()->{
			appointmentServiceImpl.findAppointmentsByAppointmentType("delievery consultation");
		});
		
		assertEquals("No delievery consultation appointments", exception.getMessage());
		verify(appointmentRepository,times(1)).findByAppointmentType("delievery consultation");
	}

	@Test
	void testFindAppointmentsByCustomerId() throws CustomException {
		when(customerRepository.findById(1)).thenReturn(Optional.of(customer));
		when(appointmentRepository.findByCustomerId(1)).thenReturn(Arrays.asList(appointment));
		List<Appointment> list= appointmentServiceImpl.findAppointmentsByCustomerId(1);
		assertNotNull(list);
		verify(customerRepository,times(1)).findById(1);
		verify(appointmentRepository,times(1)).findByCustomerId(1);
	}
	
	@Test
	void testFindAppointmentsByCustomerIdWhenNoCustomerFound() {
		when(customerRepository.findById(1)).thenReturn(Optional.empty());
		Exception exception=assertThrows(CustomException.class, ()->{
			appointmentServiceImpl.findAppointmentsByCustomerId(1);
		});
		assertEquals("No customer found with customer Id 1", exception.getMessage());
		verify(customerRepository,times(1)).findById(1);
		verify(appointmentRepository,never()).findByCustomerId(1);
	}

}
