package com.cts.fabfurniture.controller;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.util.Arrays;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.cts.fabfurniture.entity.Customer;
import com.cts.fabfurniture.entity.Furniture;
import com.cts.fabfurniture.entity.Product;
import com.cts.fabfurniture.service.FurnitureService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

@SpringBootTest
@AutoConfigureMockMvc
class FurnitureControllerTest {
	
	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private FurnitureService furnitureService;
	
	private static ObjectMapper objectMapper;
	private Product p=new Product();
	
	private Customer customer=new Customer(1,"kashif","kashif@gmail.com","89888899","jfjdfjdj","abc@123");
	
	private Furniture furniture = new Furniture(1, "sofa", "english willow", "yes", customer,p);
	
	@BeforeAll
	public static void setup() {
		objectMapper=new ObjectMapper();
		objectMapper.registerModules(new JavaTimeModule());
		objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
	}

	@Test
	void testGetFurnitures() throws Exception {
		when(furnitureService.readAllFurnitures()).thenReturn(Arrays.asList(furniture));
		mockMvc.perform(MockMvcRequestBuilders.get("/furniture").accept(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk()).andExpect(MockMvcResultMatchers.jsonPath("$.length()").value(1));
	}
	
	@Test
	void testGetFurnituresForStorageOption() throws Exception {
		when(furnitureService.findFunitureByStorageOption("Yes")).thenReturn(Arrays.asList(furniture));
		mockMvc.perform(MockMvcRequestBuilders.get("/furniture?storageOption=Yes").accept(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk()).andExpect(MockMvcResultMatchers.jsonPath("$.length()").value(1));
	}
	
	@Test
	void testGetFurnituresForWillowType() throws Exception {
		when(furnitureService.findFurnitureByWillowType("english")).thenReturn(Arrays.asList(furniture));
		mockMvc.perform(MockMvcRequestBuilders.get("/furniture?willowType=english").accept(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk()).andExpect(MockMvcResultMatchers.jsonPath("$.length()").value(1));
	}
	
//	@Test
//	void testGetFurnituresForFurnitureType() throws Exception {
//		when(furnitureService.findFurnitureByFunitureType("sofa")).thenReturn(Arrays.asList(furniture));
//		mockMvc.perform(MockMvcRequestBuilders.get("/furniture?furnitureType=sofa").accept(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk()).andExpect(MockMvcResultMatchers.jsonPath("$.length()").value(1));
//	}
	
	@Test
	void testGetFurnituresForCustomerId() throws Exception {
		when(furnitureService.findFurnitureByCustomerId(1)).thenReturn(Arrays.asList(furniture));
		mockMvc.perform(MockMvcRequestBuilders.get("/furniture?customerId=1").accept(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk()).andExpect(MockMvcResultMatchers.jsonPath("$.length()").value(1));
	}

	@Test
	void testGetFurniture() throws Exception {
		when(furnitureService.readFurniture(1)).thenReturn(furniture);
		mockMvc.perform(MockMvcRequestBuilders.get("/furniture/1").accept(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk()).andExpect(MockMvcResultMatchers.jsonPath("$.furnitureId").value(1));
	}

	@Test
	void testAddFurniture() throws  Exception {
		when(furnitureService.createFurniture(furniture)).thenReturn(furniture);
		mockMvc.perform(MockMvcRequestBuilders.post("/furniture").contentType(MediaType.APPLICATION_JSON).content(objectMapper.writeValueAsBytes(furniture)).accept(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isCreated()).andExpect(MockMvcResultMatchers.jsonPath("$.furnitureId").value(1));
	}

	@Test
	void testUpdateFurniture() throws JsonProcessingException, Exception {
		when(furnitureService.updateFurniture(furniture)).thenReturn(furniture);
		mockMvc.perform(MockMvcRequestBuilders.put("/furniture").contentType(MediaType.APPLICATION_JSON).content(objectMapper.writeValueAsBytes(furniture)).accept(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk()).andExpect(MockMvcResultMatchers.jsonPath("$.furnitureId").value(1));
	}

	@Test
	void testDeleteFurniture() throws Exception {
		doNothing().when(furnitureService).deleteFurniture(1);
		mockMvc.perform(MockMvcRequestBuilders.delete("/furniture/1"));
	}

}
