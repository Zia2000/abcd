package com.cts.fabfurniture.controller;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.util.Arrays;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.cts.fabfurniture.entity.Customer;
import com.cts.fabfurniture.service.CustomerService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

@SpringBootTest
@AutoConfigureMockMvc
class CustomerControllerTest {
	
	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private CustomerService customerService;
	
	private static ObjectMapper objectMapper;
	
	
	private Customer customer=new Customer(1,"kashif","kashif@gmail.com","89888899","jfjdfjdj","abc@123");
	
	@BeforeAll
	public static void setup() {
		objectMapper=new ObjectMapper();
		objectMapper.registerModules(new JavaTimeModule());
		objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
	}

	@Test
	void testLoginCustomer() throws Exception {
		when(customerService.loginCustomer("kashif@gmail.com", "abc@123")).thenReturn(customer);
		mockMvc.perform(MockMvcRequestBuilders.get("/customer/login?emailId=kashif@gmail.com&password=abc@123").accept(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk()).andExpect(MockMvcResultMatchers.jsonPath("$.customerId").value(1));
	}

	@Test
	void testGetCustomers() throws Exception {
		when(customerService.readAllCustomer()).thenReturn(Arrays.asList(customer));
		mockMvc.perform(MockMvcRequestBuilders.get("/customer").accept(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk()).andExpect(MockMvcResultMatchers.jsonPath("$.length()").value(1));
	
	}

	@Test
	void testGetCustomer() throws Exception {
		when(customerService.readCustomer(1)).thenReturn(customer);
		mockMvc.perform(MockMvcRequestBuilders.get("/customer/1").accept(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk()).andExpect(MockMvcResultMatchers.jsonPath("$.customerId").value(1));
	}

	@Test
	void testSaveCustomer() throws  Exception {
		when(customerService.createCustomer(customer)).thenReturn(customer);
		mockMvc.perform(MockMvcRequestBuilders.post("/customer").contentType(MediaType.APPLICATION_JSON).content(objectMapper.writeValueAsBytes(customer)).accept(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isCreated()).andExpect(MockMvcResultMatchers.jsonPath("$.customerId").value(1));
	
	}

	@Test
	void testUpdateCustomer() throws Exception {
		when(customerService.updateCustomer(customer)).thenReturn(customer);
		mockMvc.perform(MockMvcRequestBuilders.put("/customer").contentType(MediaType.APPLICATION_JSON).content(objectMapper.writeValueAsBytes(customer)).accept(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk()).andExpect(MockMvcResultMatchers.jsonPath("$.customerId").value(1));
	}

	@Test
	void testDeleteCustomer() throws Exception {
		doNothing().when(customerService).deleteCustomer(1);
		mockMvc.perform(MockMvcRequestBuilders.delete("/customer/1"));
	}

}
