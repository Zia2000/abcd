package com.cts.fabfurniture.controller;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Date;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.cts.fabfurniture.entity.Appointment;
import com.cts.fabfurniture.entity.Customer;
import com.cts.fabfurniture.service.AppointmentService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

@SpringBootTest
@AutoConfigureMockMvc
class AppointmentControllerTest {
	
	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private AppointmentService appointmentService;
	
	private static ObjectMapper objectMapper;
	
	private Customer customer=new Customer(1,"kashif","kashif@gmail.com","89888899","jfjdfjdj","abc@123");
	
	private Appointment appointment=new Appointment(1,"in store","Chennai",new Date(),customer);
	
	@BeforeAll
	public static void setup() {
		objectMapper=new ObjectMapper();
		objectMapper.registerModules(new JavaTimeModule());
		objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
	}


	@Test
	void testGetAppointments() throws Exception {
		when(appointmentService.readAllAppointments()).thenReturn(Arrays.asList(appointment));
		mockMvc.perform(MockMvcRequestBuilders.get("/appointment").accept(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk()).andExpect(MockMvcResultMatchers.jsonPath("$.length()").value(1));
	}
	
	@Test
	void testGetAppointmentsForLocation() throws Exception {
		when(appointmentService.findAppointmentsByLocation("Chennai")).thenReturn(Arrays.asList(appointment));
		mockMvc.perform(MockMvcRequestBuilders.get("/appointment?location=Chennai").accept(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk()).andExpect(MockMvcResultMatchers.jsonPath("$.length()").value(1));
	}
	
	@Test
	void testGetAppointmentsForAppointmentType() throws Exception {
		when(appointmentService.findAppointmentsByAppointmentType("in store")).thenReturn(Arrays.asList(appointment));
		mockMvc.perform(MockMvcRequestBuilders.get("/appointment?appointmentType=in store").accept(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk()).andExpect(MockMvcResultMatchers.jsonPath("$.length()").value(1));
	}
	
	@Test
	void testGetAppointmentsForCustomerId() throws Exception {
		when(appointmentService.findAppointmentsByCustomerId(1)).thenReturn(Arrays.asList(appointment));
		mockMvc.perform(MockMvcRequestBuilders.get("/appointment?customerId=1").accept(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk()).andExpect(MockMvcResultMatchers.jsonPath("$.length()").value(1));
	}


	@Test
	void testGetAppointment() throws Exception {
		when(appointmentService.readAppointment(1)).thenReturn(appointment);
		mockMvc.perform(MockMvcRequestBuilders.get("/appointment/1").accept(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk()).andExpect(MockMvcResultMatchers.jsonPath("$.appointmentId").value(1));
	}

	@Test
	void testSaveAppointment() throws  Exception {
		when(appointmentService.createAppointment(appointment)).thenReturn(appointment);
		mockMvc.perform(MockMvcRequestBuilders.post("/appointment").contentType(MediaType.APPLICATION_JSON).content(objectMapper.writeValueAsBytes(appointment)).accept(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isCreated()).andExpect(MockMvcResultMatchers.jsonPath("$.appointmentId").value(1));
	}

	@Test
	void testUpdateAppointment() throws Exception {
		when(appointmentService.updateAppointment(appointment)).thenReturn(appointment);
		mockMvc.perform(MockMvcRequestBuilders.put("/appointment").contentType(MediaType.APPLICATION_JSON).content(objectMapper.writeValueAsBytes(appointment)).accept(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk()).andExpect(MockMvcResultMatchers.jsonPath("$.appointmentId").value(1));
	}

	@Test
	void testDeleteAppointment() throws Exception {
		doNothing().when(appointmentService).deleteAppointment(1);
		mockMvc.perform(MockMvcRequestBuilders.delete("/appointment/1"));
	}

}
