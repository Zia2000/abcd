package com.cts.fabfurniture;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FabFurnitureApplicationTests {

	@Test
	void contextLoads() {
	}

}
