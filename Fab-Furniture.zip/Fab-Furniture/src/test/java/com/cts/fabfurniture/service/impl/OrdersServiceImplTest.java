package com.cts.fabfurniture.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.timeout;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cts.fabfurniture.entity.Customer;
import com.cts.fabfurniture.entity.Furniture;
import com.cts.fabfurniture.entity.Orders;
import com.cts.fabfurniture.exception.CustomException;
import com.cts.fabfurniture.repository.OrdersRepository;


@ExtendWith(MockitoExtension.class)
class OrdersServiceImplTest {
	
	@Mock
	private OrdersRepository ordersRepository;
	@InjectMocks
	private OrdersServiceImpl ordersServiceImpl;
	
	Customer customer=new Customer(1,"kashif","kashif@gmail.com","89888899","jfjdfjdj","abc@123");
	
	Furniture furniture = new Furniture(1, "sofa", "english willow", "yes", customer);
	
	Orders order=new Orders(1,50000,new Date(),new Date(),customer,furniture);
	


	@Test
	void testCreateOrder() {
		when(ordersRepository.save(order)).thenReturn(order);
		ordersServiceImpl.createOrder(order);
		verify(ordersRepository,timeout(1)).save(order);
	}

	@Test
	void testReadOrder() throws CustomException {
		when(ordersRepository.findById(1)).thenReturn(Optional.of(order));
		ordersServiceImpl.readOrder(1);
		verify(ordersRepository,times(1)).findById(1);
	}
	
	@Test
	void testReadOrderWhenNoOrderFound() {
		when(ordersRepository.findById(2)).thenReturn(Optional.empty());
		Exception exception=assertThrows(CustomException.class, ()->{
			ordersServiceImpl.readOrder(2);
		});
		assertEquals("No order found for order Id 2",exception.getMessage());
		verify(ordersRepository,times(1)).findById(2);
	}

	@Test
	void testReadAllOrders() {
		when(ordersRepository.findAll()).thenReturn(Arrays.asList(order));
		List<Orders> list=ordersServiceImpl.readAllOrders();
		assertNotNull(list);
		verify(ordersRepository,times(1)).findAll();
	}

	@Test
	void testUpdateOrder() {
		when(ordersRepository.save(order)).thenReturn(order);
		ordersServiceImpl.updateOrder(order);
		verify(ordersRepository,times(1)).save(order);
	}

	@Test
	void testDeleteOrder() throws CustomException {
		when(ordersRepository.findById(1)).thenReturn(Optional.of(order));
		doNothing().when(ordersRepository).delete(order);
		ordersServiceImpl.deleteOrder(1);
		verify(ordersRepository,times(1)).findById(1);
		verify(ordersRepository,times(1)).delete(order);
	}
	
	@Test
	void testDeleteOrderWhenNoOrderFound() throws CustomException {
		when(ordersRepository.findById(2)).thenReturn(Optional.empty());
		Exception exception=assertThrows(CustomException.class, ()->{
			ordersServiceImpl.deleteOrder(2);
		});
		assertEquals("No order exists with order Id 2", exception.getMessage());
		verify(ordersRepository,times(1)).findById(2);
		verify(ordersRepository,never()).delete(order);
		
	}
	

	@Test
	void testFindOrdersByCustomerId() throws CustomException {
		when(ordersRepository.findByCustomerId(1)).thenReturn(Arrays.asList(order));
		List<Orders> list= ordersServiceImpl.findOrdersByCustomerId(1);
		assertNotNull(list);
		
		verify(ordersRepository,times(1)).findByCustomerId(1);
	}
	
	@Test
	void testFindOrdersByCustomerIdWhenNoOrdersFound() {
		when(ordersRepository.findByCustomerId(2)).thenReturn(new ArrayList<>());
		Exception exception=assertThrows(CustomException.class, ()->{
			ordersServiceImpl.findOrdersByCustomerId(2);
		});
		assertEquals("No Orders found with Customer Id 2", exception.getMessage());
		
		verify(ordersRepository,times(1)).findByCustomerId(2);
	}

	@Test
	void testFindOrdersByFurnitureId() throws CustomException {
		when(ordersRepository.findByFurnitureId(1)).thenReturn(Arrays.asList(order));
		List<Orders> list=ordersServiceImpl.findOrdersByFurnitureId(1);
		assertNotNull(list);
		
		verify(ordersRepository,times(1)).findByFurnitureId(1);
	}
	
	@Test
	void testFindOrdersByFurnitureIdWhenNoOrdersFound() {
		when(ordersRepository.findByFurnitureId(2)).thenReturn(new ArrayList<>());
		Exception exception=assertThrows(CustomException.class, ()->{
			ordersServiceImpl.findOrdersByFurnitureId(2);
		});
		assertEquals("No Orders found with Furniture Id 2", exception.getMessage());
		
		verify(ordersRepository,times(1)).findByFurnitureId(2);
	}

	@Test
	void testFindOrdersByTotalAmount() throws CustomException {
		when(ordersRepository.findByTotalAmount(50000)).thenReturn(Arrays.asList(order));
		List<Orders> list=ordersServiceImpl.findOrdersByTotalAmount(50000);
		assertNotNull(list);
		verify(ordersRepository,times(1)).findByTotalAmount(50000);
	}
	
	@Test
	void testFindOrdersByTotalAmountWhenNoOrderFound() {
		when(ordersRepository.findByTotalAmount(20000)).thenReturn(new ArrayList<>());
		Exception exception=assertThrows(CustomException.class, ()->{
			ordersServiceImpl.findOrdersByTotalAmount(20000);
		});
		assertEquals("No orders found for total amount 20000.0", exception.getMessage());
		verify(ordersRepository,times(1)).findByTotalAmount(20000);
	}

}
