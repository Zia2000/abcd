package com.cts.fabfurniture.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cts.fabfurniture.entity.Customer;
import com.cts.fabfurniture.entity.Furniture;
import com.cts.fabfurniture.exception.CustomException;
import com.cts.fabfurniture.repository.CustomerRepository;
import com.cts.fabfurniture.repository.FurnitureRepository;

@ExtendWith(MockitoExtension.class)
class FurnitureServiceImplTest {

	@Mock
	private FurnitureRepository furnitureRepository;
	
	@Mock
	private CustomerRepository customerRepository;

	@InjectMocks
	private FurnitureServiceImpl furnitureServiceImpl;

	Customer customer = new Customer(1, "kashif", "kashif@gmail.com", "89888899", "jfjdfjdj", "abc@123");

	Furniture furniture = new Furniture(1, "sofa", "english willow", "yes", customer);

	@Test
	void testCreateFurniture() {
		when(furnitureRepository.save(furniture)).thenReturn(furniture);
		furnitureServiceImpl.createFurniture(furniture);
		verify(furnitureRepository, times(1)).save(furniture);
	}

	@Test
	void testReadFurniture() throws CustomException {
		when(furnitureRepository.findById(1)).thenReturn(Optional.of(furniture));
		furnitureServiceImpl.readFurniture(1);
		verify(furnitureRepository, times(1)).findById(1);
	}

	@Test
	void testReadFurnitureWhenNoFurnitureFound() {
		when(furnitureRepository.findById(2)).thenReturn(Optional.empty());
		Exception exception = assertThrows(CustomException.class, () -> {
			furnitureServiceImpl.readFurniture(2);
		});
		assertEquals("No furniture found with id 2", exception.getMessage());
		verify(furnitureRepository, times(1)).findById(2);
	}

	@Test
	void testReadAllFurnitures() {
		when(furnitureRepository.findAll()).thenReturn(Arrays.asList(furniture));
		List<Furniture> list = furnitureServiceImpl.readAllFurnitures();
		assertNotNull(list);
		verify(furnitureRepository, times(1)).findAll();
	}

	@Test
	void testUpdateFurniture() {
		when(furnitureRepository.save(furniture)).thenReturn(furniture);
		furnitureServiceImpl.updateFurniture(furniture);
		verify(furnitureRepository, times(1)).save(furniture);
	}

	@Test
	void testDeleteFurniture() throws CustomException {
		when(furnitureRepository.findById(1)).thenReturn(Optional.of(furniture));
		doNothing().when(furnitureRepository).delete(furniture);
		furnitureServiceImpl.deleteFurniture(1);
		verify(furnitureRepository, times(1)).findById(1);
		verify(furnitureRepository, times(1)).delete(furniture);

	}

	@Test
	void testDeleteFurnitueWhenNoFurnitureFound() {
		when(furnitureRepository.findById(1)).thenReturn(Optional.empty());

		Exception exception = assertThrows(CustomException.class, () -> {
			furnitureServiceImpl.deleteFurniture(1);
		});
		assertEquals("No furniture found with id 1", exception.getMessage());
		verify(furnitureRepository, times(1)).findById(1);
		verify(furnitureRepository, never()).delete(furniture);
	}

//	@Test
//	void testFindFurnitureByFunitureType() throws CustomException {
//		when(furnitureRepository.findByFurnitureType("sofa")).thenReturn(Arrays.asList(furniture));
//		List<Furniture> list = furnitureServiceImpl.findFurnitureByFunitureType("sofa");
//		assertNotNull(list);
//		verify(furnitureRepository, times(1)).findByFurnitureType("sofa");
//	}
//
//	@Test
//	void testFindFurnitureByFunitureTypeWhenNoFurnitureFound() {
//		when(furnitureRepository.findByFurnitureType("Bed")).thenReturn(new ArrayList<>());
//		Exception exception = assertThrows(CustomException.class, () -> {
//			furnitureServiceImpl.findFurnitureByFunitureType("Bed");
//		});
//		assertEquals("No furniture found for furniture type Bed", exception.getMessage());
//		verify(furnitureRepository, times(1)).findByFurnitureType("Bed");
//	}

	@Test
	void testFindFurnitureByWillowType() throws CustomException {
		when(furnitureRepository.findByWillowType("english willow")).thenReturn(Arrays.asList(furniture));
		List<Furniture> list = furnitureServiceImpl.findFurnitureByWillowType("english willow");
		assertNotNull(list);
		verify(furnitureRepository, times(1)).findByWillowType("english willow");
	}

	@Test
	void testFindFurnitureByWillowTypeWhenNoFurnitureFound() {
		when(furnitureRepository.findByWillowType("kashmir")).thenReturn(new ArrayList<>());
		Exception exception = assertThrows(CustomException.class, () -> {
			furnitureServiceImpl.findFurnitureByWillowType("kashmir");
		});
		assertEquals("No furniture found for kashmir willow", exception.getMessage());
		verify(furnitureRepository, times(1)).findByWillowType("kashmir");
	}

	@Test
	void testFindFunitureByStorageOption() throws CustomException {
		when(furnitureRepository.findByStorageOption("yes")).thenReturn(Arrays.asList(furniture));
		List<Furniture> list = furnitureServiceImpl.findFunitureByStorageOption("yes");
		assertNotNull(list);
		verify(furnitureRepository, times(1)).findByStorageOption("yes");
	}

	@Test
	void testFindFunitureByStorageOptionWhenNoFurnitureFound() {
		when(furnitureRepository.findByStorageOption("no")).thenReturn(new ArrayList<>());
		Exception exception = assertThrows(CustomException.class, () -> {
			furnitureServiceImpl.findFunitureByStorageOption("no");
		});
		assertEquals("No furniture found with storage option ", exception.getMessage());
		verify(furnitureRepository, times(1)).findByStorageOption("no");
	}

	@Test
	void testFindFurnitureByCustomerId() throws CustomException {
		
		when(furnitureRepository.findByCustomerId(1)).thenReturn(Arrays.asList(furniture));
		List<Furniture> list= furnitureServiceImpl.findFurnitureByCustomerId(1);
		assertNotNull(list);
		
		verify(furnitureRepository,times(1)).findByCustomerId(1);
	}
	
	@Test
	void testFindFurnitureByCustomerIdWhenNoCustomerFound() {
		when(furnitureRepository.findByCustomerId(1)).thenReturn(new ArrayList<>());
		Exception exception=assertThrows(CustomException.class, ()->{
			furnitureServiceImpl.findFurnitureByCustomerId(1);
		});
		assertEquals("No furniture found for customer Id 1", exception.getMessage());
		
		verify(furnitureRepository,times(1)).findByCustomerId(1);
	}

}
