package com.cts.fabfurniture.exception;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;



@RestController
@ControllerAdvice
public class GlobalException {

	
	@ExceptionHandler(CustomException.class)
	public ResponseEntity<ErrorEntity> handleCustomException(CustomException customException) {
		
		ErrorEntity error=new ErrorEntity("400", customException.getMessage(), new Date());
		return new ResponseEntity<>(error,HttpStatus.BAD_REQUEST);
	}
}
