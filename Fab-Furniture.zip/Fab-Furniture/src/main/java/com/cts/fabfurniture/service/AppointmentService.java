package com.cts.fabfurniture.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cts.fabfurniture.entity.Appointment;
import com.cts.fabfurniture.exception.CustomException;

@Service
public interface AppointmentService {

	public Appointment createAppointment(Appointment appointment);
	public Appointment readAppointment(int appointmentId) throws CustomException;
	public List<Appointment> readAllAppointments();
	public Appointment updateAppointment(Appointment appointment);
	public void deleteAppointment(int appointmentId) throws CustomException;
	public List<Appointment> findAppointmentsByLocation(String location) throws CustomException;
	public List<Appointment> findAppointmentsByAppointmentType(String appointmentType) throws CustomException;
	public List<Appointment> findAppointmentsByCustomerId(int customerId) throws CustomException;
}
