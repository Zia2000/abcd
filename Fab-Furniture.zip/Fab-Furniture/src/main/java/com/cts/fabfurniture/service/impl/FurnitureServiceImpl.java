package com.cts.fabfurniture.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.fabfurniture.entity.Furniture;
import com.cts.fabfurniture.exception.CustomException;
import com.cts.fabfurniture.repository.FurnitureRepository;
import com.cts.fabfurniture.service.FurnitureService;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class FurnitureServiceImpl implements FurnitureService {
	
	@Autowired
	private FurnitureRepository furnitureRepository;

	@Override
	public Furniture createFurniture(Furniture furniture) {
		log.info("reateFurniture method invoked");
		Furniture addedFurniture=furnitureRepository.save(furniture);
		log.debug("Added Furniture "+addedFurniture);
		log.info("Furniture saved");
		return addedFurniture;
	}

	@Override
	public Furniture readFurniture(int furnitureId) throws CustomException {
		log.info("readFurniture method invoked");
		Optional<Furniture> furniture=furnitureRepository.findById(furnitureId);
		if(furniture.isEmpty()) {
			throw new CustomException("No furniture found with id "+furnitureId);
		}
		log.debug("furniture with id "+furnitureId+" "+furniture.get());
		return furniture.get();
	}

	@Override
	public List<Furniture> readAllFurnitures() {
		log.info("readAllFurniture method invoked");
		List<Furniture> furnitureList=furnitureRepository.findAll();
		log.debug("List of all furnitures "+furnitureList);
		return furnitureList;
	}

	@Override
	public Furniture updateFurniture(Furniture furniture) {
		log.info("updateFurniture method invoked");
		Furniture updatedFurniture=furnitureRepository.save(furniture);
		log.debug("Updated furniture "+updatedFurniture);
		return furniture;
	}

	@Override
	public void deleteFurniture(int furnitureId) throws CustomException {
       log.info("deleteFurniture method invoked");
       Optional<Furniture> furniture=furnitureRepository.findById(furnitureId);
       if(furniture.isEmpty()) {
    	   throw new CustomException("No furniture found with id "+furnitureId);
       }
       log.debug("deleted Furniture "+furniture.get());
       furnitureRepository.delete(furniture.get());
	}

	@Override
	public List<Furniture> findAllByMaterialType(String type) throws CustomException {
		log.info("finding furniture by type");
		List<Furniture> furnitureList=furnitureRepository.findByMaterialType(type);
		if(furnitureList.isEmpty()) {
			throw new CustomException("No furniture found for material type "+type);
		}
		log.debug("List of funirture by type "+furnitureList);
		return furnitureList;
	}

	@Override
	public List<Furniture> findFurnitureByWillowType(String willowType) throws CustomException {
		log.info("finding furniture by willow type");
		List<Furniture> furnitureList=furnitureRepository.findByWillowType(willowType);
		if(furnitureList.isEmpty()) {
			throw new CustomException("No furniture found for "+willowType+" willow");
		}
		log.debug("List of funirture by willow type "+furnitureList);
		return furnitureList;
	}

	@Override
	public List<Furniture> findFunitureByStorageOption(String storageOption) throws CustomException {
		log.info("finding furniture by storage option");
		List<Furniture> furnitureList=furnitureRepository.findByStorageOption(storageOption);
		if(furnitureList.isEmpty()) {
			throw new CustomException("No furniture found with storage option ");
		}
		log.debug("List of funirture with storage option "+furnitureList);
		return furnitureList;
		
	}

	@Override
	public List<Furniture> findFurnitureByCustomerId(int customerId) throws CustomException {
		log.info("Finding furniture by Customer Id");
		List<Furniture> furnitureList=furnitureRepository.findByCustomerId(customerId);
		if(furnitureList.isEmpty()) {
			throw new CustomException("No furniture found for customer Id "+customerId);
		}
		log.debug("List of Furniture with customer Id "+customerId+" "+furnitureList);
		return furnitureList;
	}

}
