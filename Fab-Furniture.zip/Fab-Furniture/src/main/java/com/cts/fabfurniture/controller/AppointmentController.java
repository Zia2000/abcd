package com.cts.fabfurniture.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.fabfurniture.entity.Appointment;
import com.cts.fabfurniture.exception.CustomException;
import com.cts.fabfurniture.service.AppointmentService;

@RestController
@RequestMapping("/appointment")
public class AppointmentController {

	@Autowired
	private AppointmentService appointmentService;

	@GetMapping("/admin/findAll")
	public ResponseEntity<Object> getAppointments(@RequestParam(value = "location", required = false) String location,
			@RequestParam(value = "appointmentType", required = false) String appointmentType)
			throws CustomException {
		List<Appointment> appointmentList = null;
		if (location != null) {
			appointmentList = appointmentService.findAppointmentsByLocation(location);
		} else if (appointmentType != null) {
			appointmentList = appointmentService.findAppointmentsByAppointmentType(appointmentType);
		}  else {
			appointmentList = appointmentService.readAllAppointments();
		}
		return new ResponseEntity<>(appointmentList, HttpStatus.OK);
	}
	
	@GetMapping("/findAll/{customerId}")
	public ResponseEntity<Object> getAppointmentsForCustomerId(@PathVariable int customerId) throws CustomException{
		List<Appointment> appointmentList=appointmentService.findAppointmentsByCustomerId(customerId);
		return new ResponseEntity<Object> (appointmentList,HttpStatus.OK);
	}

	@GetMapping("/find/{id}")
	public ResponseEntity<Appointment> getAppointment(@PathVariable int id) throws CustomException {
		Appointment appointment = appointmentService.readAppointment(id);
		return new ResponseEntity<>(appointment, HttpStatus.OK);
	}

	@PostMapping("/create")
	public ResponseEntity<Object> saveAppointment(@RequestBody Appointment appointment) {
		Appointment savedAppointment = appointmentService.createAppointment(appointment);
		return new ResponseEntity<>(savedAppointment, HttpStatus.CREATED);
	}

	@PutMapping("/update")
	public ResponseEntity<Appointment> updateAppointment(@RequestBody Appointment appointment) {
		Appointment updatedAppointment = appointmentService.updateAppointment(appointment);
		return new ResponseEntity<>(updatedAppointment, HttpStatus.OK);
	}

	@DeleteMapping("/delete/{id}")
	public void deleteAppointment(@PathVariable int id) throws CustomException {
		appointmentService.deleteAppointment(id);
	}
}
