package com.cts.fabfurniture.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.fabfurniture.entity.Orders;
import com.cts.fabfurniture.exception.CustomException;
import com.cts.fabfurniture.repository.OrdersRepository;
import com.cts.fabfurniture.service.OrdersService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class OrdersServiceImpl implements OrdersService {
	
    @Autowired
    private OrdersRepository ordersRepository;

	@Override
	public Orders createOrder(Orders order) {
		log.info("createOrder method invoked");
		Orders createdOrder=ordersRepository.save(order);
		log.debug("Order saved ",createdOrder);
		return createdOrder;
	}

	@Override
	public Orders readOrder(int orderId) throws CustomException {
		log.info("readOrder method invoked");
		Optional<Orders> order=ordersRepository.findById(orderId);
		if(order.isEmpty()) {
			throw new CustomException("No order found for order Id "+ orderId);
		}
		log.debug("Order with order id "+orderId+" "+ order.get());
		return order.get();
	}

	@Override
	public List<Orders> readAllOrders() {
		log.info("readAllOrders method invoked");
		List<Orders> ordersList=ordersRepository.findAll();
		log.debug("Orders list "+ordersList);
		return ordersList;
	}

	@Override
	public Orders updateOrder(Orders order) {
		log.info("updateOrder method invoked");
		Orders updatedOrder=ordersRepository.save(order);
		log.debug("updated Order "+updatedOrder);
		return updatedOrder;
	}

	@Override
	public void deleteOrder(int orderId) throws CustomException {
       log.info("deleteOrder method invoked");
       Optional<Orders> order=ordersRepository.findById(orderId);
       if(order.isEmpty()) {
    	   throw new CustomException("No order exists with order Id "+orderId);
       }
       log.debug("deleting order "+order);
       ordersRepository.delete(order.get());
	}

	@Override
	public List<Orders> findOrdersByCustomerId(int customerId) throws CustomException {
		log.info("findOrdersByCustomerId invoked");
		List<Orders> ordersList=ordersRepository.findByCustomerId(customerId);
		if(ordersList.isEmpty()) {
			throw new CustomException("No Orders found with Customer Id "+customerId);
		}
		log.debug("Orders list for customer id "+customerId+" is "+ordersList);
		
		return ordersList;
	}

	@Override
	public List<Orders> findOrdersByFurnitureId(int furnitureId) throws CustomException {
		log.info("findOrderByFurnitureId method is invoked");
		List<Orders> ordersList=ordersRepository.findByFurnitureId(furnitureId);
		if(ordersList.isEmpty()) {
			throw new CustomException("No Orders found with Furniture Id "+furnitureId);
			
		}
		log.debug("Orders list for furniture id "+furnitureId+" is "+ordersList);
		return ordersList;
	}

	@Override
	public List<Orders> findOrdersByTotalAmount(double amount) throws CustomException {
		log.info("findOrdersByTotalAmount method invoked");
		List<Orders> ordersList=ordersRepository.findByTotalAmount(amount);
		if(ordersList.isEmpty()) {
			throw new CustomException("No orders found for total amount "+amount);
			
		}
		log.debug("Order list for amount "+amount+" "+ordersList);
		return ordersList;
	}

}
