package com.cts.fabfurniture.service;

import java.util.List;

import org.springframework.security.access.event.PublicInvocationEvent;
import org.springframework.stereotype.Service;

import com.cts.fabfurniture.entity.Product;
import com.cts.fabfurniture.exception.CustomException;

@Service
public interface ProductService {
	
	public Product createPoduct(Product product);
	public Product updateProduct(Product product);
	public Product readProduct(int productId) throws CustomException;
	public List<Product> readAllProduct();
	public void deleteProduct(int productId) throws CustomException;
	public List<Product> findAllProductsByType(String type) throws CustomException;

}
