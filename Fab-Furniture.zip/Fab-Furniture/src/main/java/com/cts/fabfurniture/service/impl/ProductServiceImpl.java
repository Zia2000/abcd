package com.cts.fabfurniture.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.aop.ThrowsAdvice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.jaxb.SpringDataJaxb.PageRequestDto;
import org.springframework.stereotype.Service;

import com.cts.fabfurniture.entity.Product;
import com.cts.fabfurniture.exception.CustomException;
import com.cts.fabfurniture.repository.ProductRepository;
import com.cts.fabfurniture.service.ProductService;
@Service
public class ProductServiceImpl implements ProductService {
	
	@Autowired
	ProductRepository productRepository;

	@Override
	public Product createPoduct(Product product) {
	
		Product createdProduct=productRepository.save(product);
		return createdProduct;
	}

	@Override
	public Product updateProduct(Product product) {
		// TODO Auto-generated method stub
		Product  updatedProduct=productRepository.save(product);
		return updatedProduct;
	}

	@Override
	public Product readProduct(int productId) throws CustomException {
		// TODO Auto-generated method stub
		Optional<Product> product=productRepository.findById(productId);
		if(product.isEmpty()) {
			throw new CustomException("No Product exist with product id :"+productId);
			
		}
		return product.get();
	}

	@Override
	public List<Product> readAllProduct() {
		// TODO Auto-generated method stub
		List<Product> productList=productRepository.findAll();
		return productList;
	}

	@Override
	public void deleteProduct(int productId) throws CustomException {
		
		Optional<Product> product=productRepository.findById(productId);
		if(product.isEmpty()) {
			throw new CustomException("No Product Found with id "+productId);
		}
		productRepository.delete(product.get());
	}

	@Override
	public List<Product> findAllProductsByType(String type) throws CustomException {
		List<Product> productList=productRepository.findAllByProductType(type);
		if(productList.isEmpty()) {
			throw new CustomException("No Product Found for product type: "+type);
		}
		return productList;
	}

}
