package com.cts.fabfurniture.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.fabfurniture.entity.Orders;
import com.cts.fabfurniture.exception.CustomException;
import com.cts.fabfurniture.service.OrdersService;

@RestController
@RequestMapping("/orders")
public class OrdersController {

	@Autowired
	private OrdersService ordersService;

	
	//findAll?customerId=[^0]**
	//findAll?customerId=0&fun**
	@GetMapping("/admin/findAll")
	public ResponseEntity<Object> getOrders(
			@RequestParam(value = "furnitureId", required = false, defaultValue = "0") int furnitureId,
			@RequestParam(value = "totalAmount", required = false, defaultValue = "0") double totalAmount)
			throws CustomException {

		List<Orders> orderslList = null;
		if (furnitureId != 0) {
			orderslList = ordersService.findOrdersByFurnitureId(furnitureId);
		} else if (totalAmount != 0) {
			orderslList = ordersService.findOrdersByTotalAmount(totalAmount);
		} else {
			orderslList = ordersService.readAllOrders();
		}
		return new ResponseEntity<Object>(orderslList, HttpStatus.OK);
	}
	@GetMapping("/findAll/{customerId}")
	public ResponseEntity<Object> getOrdersListForCustomer(@PathVariable int customerId) throws CustomException{
		List<Orders> orderList=ordersService.findOrdersByCustomerId(customerId);
		return new ResponseEntity<Object> (orderList,HttpStatus.OK);
	}
	@GetMapping("/find/{id}")
	public ResponseEntity<Object> getOrder(@PathVariable int id) throws CustomException{
		Orders order=ordersService.readOrder(id);
		return new ResponseEntity<Object>(order,HttpStatus.OK);
	}
	
	@PostMapping("/create")
	public ResponseEntity<Object> saveOrder(@RequestBody Orders order){
		Orders savedOrder=ordersService.createOrder(order);
		return new ResponseEntity<Object>(savedOrder,HttpStatus.CREATED);
	}
	
	@PutMapping("/update")
	public ResponseEntity<Object> updateOrder(@RequestBody Orders order){
		Orders updatedOrder=ordersService.updateOrder(order);
		return new ResponseEntity<Object> (updatedOrder,HttpStatus.OK);
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> deleteOrder(@PathVariable int id) throws CustomException{
		ordersService.deleteOrder(id);
		return new ResponseEntity<String>("Order deleted succesfully",HttpStatus.OK);
		
	}
}
