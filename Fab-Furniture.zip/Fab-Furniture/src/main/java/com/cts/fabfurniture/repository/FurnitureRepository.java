package com.cts.fabfurniture.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.fabfurniture.entity.Furniture;


@Repository
public interface FurnitureRepository extends JpaRepository<Furniture, Integer>{

	public List<Furniture> findByMaterialType(String type);
	public List<Furniture> findByWillowType(String willowType);
	public List<Furniture> findByStorageOption(String storageOption);
	
	@Query(value = "Select * from Furniture where customer_id=:customerId",nativeQuery = true)
	public List<Furniture> findByCustomerId(@Param(value = "customerId") int customerId);
//	@Query(value = "Select * from Furniture where furniture_type=:type",nativeQuery = true)
//	public List<Furniture> findByFurnitureType(@Param(value = "type") String type);
}
