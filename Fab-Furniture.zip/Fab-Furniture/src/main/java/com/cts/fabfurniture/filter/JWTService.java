package com.cts.fabfurniture.filter;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.cts.fabfurniture.dto.LoginDto;
import com.cts.fabfurniture.entity.Customer;
import com.cts.fabfurniture.repository.CustomerRepository;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

@Component
public class JWTService {

	public final String adminEmail = "admin@gmail.com";
	public final String adminPass = "admin";
	
	
	@Autowired
	private CustomerRepository customerRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;

	protected static String generateToken(String name, Collection<? extends GrantedAuthority> authorities) {
		String jwt = Jwts.builder().issuer("FabFurniture").subject("JWT Token").claim("username", name)
				.claim("authorities", populateAuthorities(authorities)).issuedAt(new Date())
				.expiration(new Date((new Date()).getTime() + 30000000)).signWith(Keys.hmacShaKeyFor(SecurityConstants.JWT_KEY.getBytes(StandardCharsets.UTF_8))).compact();
		return jwt;
	}

	private static String populateAuthorities(Collection<? extends GrantedAuthority> collection) {
		Set<String> authoritiesSet = new HashSet<>();
		for (GrantedAuthority authority : collection) {
			authoritiesSet.add(authority.getAuthority());
		}
		return String.join(",", authoritiesSet);
	}
    

	public String loginUser(LoginDto loginDto) {
		
		String username = loginDto.getUsername();
		String pwd = loginDto.getPassword();
		List<GrantedAuthority> authorities;
		Optional<Customer> customer = customerRepository.findByEmailId(username);
		System.out.println("customer"+ customer.isPresent() +" "+loginDto.getUsername());
		authorities = new ArrayList<>();
		if (customer.isPresent()) {
			if (passwordEncoder.matches(pwd, customer.get().getPassword())) {
				authorities.add(new SimpleGrantedAuthority("ROLE_CUSTOMER"));
				String tokenString = generateToken(username, authorities);
				
				return tokenString;

			} else {
				throw new BadCredentialsException("Invalid password!");
			}
		}else if(username.equals(adminEmail)){
			if (passwordEncoder.matches(pwd, adminPass)) {
				authorities.add(new SimpleGrantedAuthority("ROLE_ADMIN"));
				String tokenString = generateToken(username, authorities);
				return tokenString;

			} else {
				throw new BadCredentialsException("Invalid password!");
			}
			
			
		}
		else {
				throw new BadCredentialsException("No user registered with this details!");
			}
		}

	}


