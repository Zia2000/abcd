package com.cts.fabfurniture.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cts.fabfurniture.entity.Orders;
import com.cts.fabfurniture.exception.CustomException;

@Service
public interface OrdersService {

	public Orders createOrder(Orders order);

	public Orders readOrder(int orderId) throws CustomException;

	public List<Orders> readAllOrders();

	public Orders updateOrder(Orders order);

	public void deleteOrder(int orderId) throws CustomException;

	public List<Orders> findOrdersByCustomerId(int customerId) throws CustomException;

	public List<Orders> findOrdersByFurnitureId(int furnitureId) throws CustomException;

	public List<Orders> findOrdersByTotalAmount(double amount) throws CustomException;

}
