package com.cts.fabfurniture.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cts.fabfurniture.entity.Furniture;
import com.cts.fabfurniture.exception.CustomException;

@Service
public interface FurnitureService {

	public Furniture createFurniture(Furniture furniture);

	public Furniture readFurniture(int furnitureId) throws CustomException;

	public List<Furniture> readAllFurnitures();

	public Furniture updateFurniture(Furniture furniture);

	public void deleteFurniture(int furnitureId) throws CustomException;

	public List<Furniture> findFurnitureByWillowType(String willowType) throws CustomException;

	public List<Furniture> findFunitureByStorageOption(String storageOption) throws CustomException;

	public List<Furniture> findFurnitureByCustomerId(int customerId) throws CustomException;

	List<Furniture> findAllByMaterialType(String type) throws CustomException;

}
