package com.cts.fabfurniture.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cts.fabfurniture.entity.Appointment;

@Repository
public interface AppointmentRepository extends JpaRepository<Appointment, Integer> {

	public List<Appointment> findByLocation(String location);
	public List<Appointment> findByAppointmentType(String appointmentType);
	@Query(value="Select * from Appointment where customer_id=:customerId",nativeQuery = true)
	public List<Appointment> findByCustomerId( int customerId);
}
