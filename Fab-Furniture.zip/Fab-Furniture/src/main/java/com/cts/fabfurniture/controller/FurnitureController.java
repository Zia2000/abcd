package com.cts.fabfurniture.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.fabfurniture.entity.Furniture;
import com.cts.fabfurniture.exception.CustomException;
import com.cts.fabfurniture.service.FurnitureService;

@RestController
@RequestMapping("/furniture")
public class FurnitureController {

	@Autowired
	private FurnitureService furnitureService;

	@GetMapping("/admin/findAll")
	public ResponseEntity<Object> getFurnitures(
			
			@RequestParam(value = "willowType", required = false) String willowType,
			@RequestParam(value = "storageOption", required = false) String storageOption)
			throws CustomException {

		List<Furniture> furnitureList = null;
		  if (willowType != null) {
			furnitureList = furnitureService.findFurnitureByWillowType(willowType);
		} else if (storageOption != null) {
			furnitureList = furnitureService.findFunitureByStorageOption(storageOption);
		}  else {
			furnitureList = furnitureService.readAllFurnitures();
		}
		return new ResponseEntity<>(furnitureList, HttpStatus.OK);
	}
	
	
	
	@GetMapping("/findAll/{customerId}")
	public ResponseEntity<Object> getFurnitureByCusotmerId(@PathVariable int customerId) throws CustomException{
		List<Furniture> furnitureList=furnitureService.findFurnitureByCustomerId(customerId);
		return new ResponseEntity<Object>(furnitureList,HttpStatus.OK);
	}
	
    @GetMapping("/find/{id}")
    public ResponseEntity<Object> getFurniture(@PathVariable int id) throws CustomException{
    	Furniture furniture=furnitureService.readFurniture(id);
    	return new ResponseEntity<>(furniture,HttpStatus.OK);
    }
    
    @PostMapping("/create")
    public ResponseEntity<Object> addFurniture(@RequestBody Furniture furniture){
    	Furniture addedFurniture=furnitureService.createFurniture(furniture);
    	return new ResponseEntity<>(addedFurniture,HttpStatus.CREATED);
    }
    
    @PutMapping("/update")
    public ResponseEntity<Object> updateFurniture(@RequestBody Furniture furniture){
    	Furniture updatedFurniture=furnitureService.updateFurniture(furniture);
    	return new ResponseEntity<>(updatedFurniture,HttpStatus.OK);
    }
    
    @DeleteMapping("/delete/{id}")
    public void deleteFurniture(@PathVariable int id) throws CustomException{
    	furnitureService.deleteFurniture(id);
    }
}
