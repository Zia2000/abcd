package com.cts.fabfurniture.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.fabfurniture.entity.Orders;

@Repository
public interface OrdersRepository extends JpaRepository<Orders, Integer> {

	@Query(value = "Select * from Orders where customer_Id=:customerId",nativeQuery = true)
	public List<Orders> findByCustomerId(@Param(value = "customerId") int customerId);
	
	@Query(value = "Select * from Orders where furniture_id=:furnitureId",nativeQuery = true)
	public List<Orders> findByFurnitureId(@Param(value = "furnitureId") int furnitureId);
	
	public List<Orders> findByTotalAmount(double amount);
	
}
