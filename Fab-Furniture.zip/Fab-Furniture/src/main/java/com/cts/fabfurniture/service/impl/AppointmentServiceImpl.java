package com.cts.fabfurniture.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.fabfurniture.entity.Appointment;
import com.cts.fabfurniture.entity.Customer;
import com.cts.fabfurniture.exception.CustomException;
import com.cts.fabfurniture.repository.AppointmentRepository;
import com.cts.fabfurniture.repository.CustomerRepository;
import com.cts.fabfurniture.service.AppointmentService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class AppointmentServiceImpl implements AppointmentService {
	
	@Autowired
	private AppointmentRepository appointmentRepository;
	
	
	@Autowired
	private CustomerRepository customerRepository;

	@Override
	public Appointment createAppointment(Appointment appointment) {
		
		log.info("createAppointemet method invoked");
		Appointment savedAppointment=appointmentRepository.save(appointment);
		log.debug("Saved Appointment "+savedAppointment);
		log.info("createAppointment method successfully completed");
		return savedAppointment;
	}

	@Override
	public Appointment readAppointment(int appointmentId) throws CustomException {
		log.info("readAppointment method invoked");
		Optional<Appointment> appointment=appointmentRepository.findById(appointmentId);
		if(appointment.isEmpty()) {
			throw new CustomException("No appointments with appointment Id "+appointmentId);
		}
		log.debug("Appointment with Id "+appointmentId+" "+appointment.get());
		log.info("readAppointment method successfully completed");
		return appointment.get();
	}

	@Override
	public List<Appointment> readAllAppointments() {
		log.info("readAllAppointments method invoked");
		List<Appointment> appointmentList=appointmentRepository.findAll();
		log.debug("list of appointments "+appointmentList);
		log.info("readAllAppointments method successfully completed");
		return appointmentList;
	}

	@Override
	public Appointment updateAppointment(Appointment appointment) {
		log.info("updateAppointment method invoked");
		Appointment updatedAppointment=appointmentRepository.save(appointment);
		log.debug("updated appointment "+updatedAppointment);
		log.info("updateAccount method successfully completed");
		return updatedAppointment;
	}

	@Override
	public void deleteAppointment(int appointmentId) throws CustomException {
        log.info("deleteAppointment method invoked");
        Optional<Appointment> appointment=appointmentRepository.findById(appointmentId);
        if(appointment.isEmpty()) {
        	throw new CustomException("No appointment present with appointment Id "+appointmentId);
        }
        log.debug("deleted appointment "+appointment.get());
        appointmentRepository.delete(appointment.get());
        log.info("deleteAppointment method successfully completed");
	}

	@Override
	public List<Appointment> findAppointmentsByLocation(String location) throws CustomException {
		log.info("findAppointmentsByLocation method invoked");
		List<Appointment> appointmentList=appointmentRepository.findByLocation(location);
		if(appointmentList.isEmpty()) {
			throw new CustomException("No appointments for the "+location+" loaction");
		}
		log.debug("Appointments for "+location+" location "+appointmentList);
		log.info("findAppointmentsByLocation method successfully completed");
		return appointmentList;
	}

	@Override
	public List<Appointment> findAppointmentsByAppointmentType(String appointmentType) throws CustomException {
		log.info("findAppointmentsByAppointmentType method successfully completed");
		List<Appointment> appointmentList=appointmentRepository.findByAppointmentType(appointmentType);
		if(appointmentList.isEmpty()) {
			throw new CustomException("No "+appointmentType+" appointments");
		}
		log.debug("list of "+appointmentType+" appointments "+appointmentList);
		log.info("findAppointmentsByAppointmentType method successfully completed");
		return appointmentList;
	}

	@Override
	public List<Appointment> findAppointmentsByCustomerId(int customerId) throws CustomException {
		log.info("findAppointmentsByCustomerId method invoked");
		Optional<Customer> customer=customerRepository.findById(customerId);
		if(customer.isEmpty()) {
			throw new CustomException("No customer found with customer Id "+customerId);
		}
		List<Appointment> appointmentList=appointmentRepository.findByCustomerId(customerId);
		log.debug("List of appointments for customer Id "+customerId);
		log.info("findAppointmentsByCustomerId method successfully completed");
		return appointmentList;
	}
	
	

}
