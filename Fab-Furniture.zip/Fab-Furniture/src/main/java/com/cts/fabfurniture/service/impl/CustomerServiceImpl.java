package com.cts.fabfurniture.service.impl;

import java.util.List;
import java.util.Optional;

import org.hibernate.id.enhanced.LegacyHiLoAlgorithmOptimizer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.fabfurniture.entity.Customer;
import com.cts.fabfurniture.exception.CustomException;
import com.cts.fabfurniture.repository.CustomerRepository;
import com.cts.fabfurniture.service.CustomerService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CustomerServiceImpl implements CustomerService {
	
	
	@Autowired
	private CustomerRepository customerRepository;

	@Override
	public Customer createCustomer(Customer customer) {
		log.info("createCustomer method invoked");
		Customer createdCustomer= customerRepository.save(customer);
		log.debug("created Customer "+createdCustomer);
		log.info("createCustomer method successfully completed");
		return createdCustomer;
		
	}

	@Override
	public Customer updateCustomer(Customer customer) {
		log.info("updateCustomer method invoked");
		Customer updatedCustomer = customerRepository.save(customer);
		log.debug("Updated customer: "+updatedCustomer);
		log.info("updateCustomer method successfully completed");
		return updatedCustomer;
	}

	@Override
	public void deleteCustomer(int customerId) throws CustomException {
		log.info("deleteCustomer method invoked");
		Optional<Customer> customer=customerRepository.findById(customerId);
		if(customer.isEmpty()) {
			throw new CustomException("Customer with customer Id "+customerId+" does not exist");
		}
		log.debug("deleted customer: "+customer.get());
		
		customerRepository.delete(customer.get());
		log.info("deleteCustomer method successfully completed");
	}

	@Override
	public Customer readCustomer(int customerId) throws CustomException {
		log.info("readCustomer method invoked");
	  Optional<Customer> customer = customerRepository.findById(customerId);
	  if(customer.isEmpty()) {
		  throw new CustomException("Customer with customer Id "+customerId+" does not exist");
	  }
	  log.debug("Customer with customerId "+customer.get());
	  log.info("readCustomer method successfully completed");
	  return customer.get();
	}

	@Override
	public List<Customer> readAllCustomer() {
		log.info("readAllCustomer method invoked");
		List<Customer> customerList=customerRepository.findAll();
		log.debug("customer list "+customerList);
		log.info("readAllCustomer method completed successfully");
		return customerList;
	}

	@Override
	public Customer findByEmailId(String emailId) throws CustomException {
		log.info("findByEmailId method invoked");
		Optional<Customer> customer=customerRepository.findByEmailId(emailId);
		if(customer.isEmpty()) {
			throw new CustomException("Customer with email Id "+emailId+" is not present");
		}
	    log.debug("customer with emailId "+emailId+" "+customer);
		log.info("findByEmailId method completed successfully");
		return customer.get();
	}

	@Override
	public Customer loginCustomer(String email,String password) throws CustomException {
		Optional<Customer> customer=customerRepository.findByEmailId(email);
		if(customer.isEmpty()) {
			throw new CustomException("No Customer found with email Id "+email);
		}
		if(!customer.get().getPassword().equals(password)) {
			throw new CustomException("Password does not match");
		}
		return customer.get();
	}

}
