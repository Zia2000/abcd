package com.cts.fabfurniture.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.fabfurniture.dto.LoginDto;
import com.cts.fabfurniture.filter.JWTService;
import com.cts.fabfurniture.repository.CustomerRepository;

@RestController
public class AuthController {
	 
		@Autowired
		CustomerRepository customerRepository;
	 
		@Autowired
		JWTService jwtService;
	 
		@PostMapping("/loginUser")
		public ResponseEntity<Object> getUserDetailsAfterLogin(@RequestBody LoginDto loginDto) {
			String tokenString  = jwtService.loginUser(loginDto);
			System.out.println(tokenString);
			return new ResponseEntity<Object>("{\"token\":\""+tokenString+"\"}" , HttpStatus.OK);
		}
	}


