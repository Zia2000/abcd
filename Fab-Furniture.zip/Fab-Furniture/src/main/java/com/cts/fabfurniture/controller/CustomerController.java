package com.cts.fabfurniture.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.fabfurniture.entity.Customer;
import com.cts.fabfurniture.exception.CustomException;
import com.cts.fabfurniture.service.CustomerService;

@RestController
@RequestMapping("/customer")
public class CustomerController {

	@Autowired
	private CustomerService customerService;

//	@GetMapping("/login")
//	public ResponseEntity<Object> loginCustomer(@RequestParam(value = "emailId", required = true) String emailId,
//			@RequestParam(value = "password", required = true) String password) throws CustomException {
//
//		 
//			return new ResponseEntity<Object>(customerService.loginCustomer(emailId, password), HttpStatus.OK);
//		
//	}
	
	@GetMapping("/admin/findAll")
	public ResponseEntity<Object> getCustomers(){
		List<Customer> customerList=customerService.readAllCustomer();
		return new ResponseEntity<Object>(customerList,HttpStatus.OK);
	}

	@GetMapping("/find/{id}")
	public ResponseEntity<Object> getCustomer(@PathVariable int id) throws CustomException {
		Customer customer = customerService.readCustomer(id);
		return new ResponseEntity<Object>(customer, HttpStatus.OK);
	}
	
	@GetMapping("/findByEmail/{emailId}")
	public ResponseEntity<Object> getCustomer(@PathVariable String emailId) throws CustomException {
		Customer customer = customerService.findByEmailId(emailId);
		return new ResponseEntity<Object>(customer, HttpStatus.OK);
	}

	@PostMapping("/create")
	public ResponseEntity<Object> saveCustomer(@RequestBody Customer customer) {
		Customer cust = customerService.createCustomer(customer);
		return new ResponseEntity<Object>(cust, HttpStatus.CREATED);
	}

	@PutMapping("/update")
	public ResponseEntity<Object> updateCustomer(@RequestBody Customer customer) {
		Customer cust = customerService.updateCustomer(customer);
		return new ResponseEntity<Object>(cust, HttpStatus.OK);
	}

	@DeleteMapping("/delete/{id}")
	public void deleteCustomer(@PathVariable int id) throws CustomException {
		customerService.deleteCustomer(id);
	}
}
