package com.cts.fabfurniture.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cts.fabfurniture.entity.Customer;
import com.cts.fabfurniture.exception.CustomException;

@Service
public interface CustomerService {
	
	public Customer createCustomer(Customer customer);
	public Customer updateCustomer(Customer customer);
	public void deleteCustomer(int customerId) throws CustomException;
	public Customer readCustomer(int customerId) throws CustomException;
	public List<Customer> readAllCustomer();
	public Customer findByEmailId(String emailId) throws CustomException;
	public Customer loginCustomer(String email,String password) throws CustomException;
		
	
	
}
